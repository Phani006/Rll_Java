package com.mphasis.eLearning.service;

import com.mphasis.eLearning.entity.Certificate;

public interface ICertificateService {
	public Certificate addCertificate(Certificate certificate);
	//public Certificate getCertificate(int employeeId);

}
