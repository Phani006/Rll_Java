package com.mphasis.eLearning.service;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mphasis.eLearning.entity.Quiz;

public interface IQuizService extends JpaRepository<Quiz, Integer>{

}
